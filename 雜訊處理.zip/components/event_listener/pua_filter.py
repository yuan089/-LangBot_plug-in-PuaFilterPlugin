import re
import asyncio
import time
from collections import Counter
from langbot_plugin.api.definition.components.common.event_listener import EventListener
from langbot_plugin.api.entities import events, context
import langbot_plugin.api.entities.builtin.platform.message as platform_message

class PuaFilter(EventListener):
    _HANDLED_ID_CACHE = set()

    async def initialize(self) -> None:
        await super().initialize()
        print("\n" + "💎"*20)
        print("🚀 [Aisin_Lychee] P8安檢員：屬性對齊模式已啟動！")
        print("✅ 發現核心屬性：response_text")
        print("💎"*20 + "\n")

        @self.handler(events.NormalMessageResponded)
        async def handle_pua_process(ctx: context.EventContext):
            event = ctx.event
            unique_id = getattr(event, "query_id", id(event))
            
            if unique_id in self._HANDLED_ID_CACHE:
                return
            
            print(f"[{time.strftime('%H:%M:%S')}] 🔎 [安檢員] 捕獲回覆 (UID: {unique_id})")

            try:
                # ==========================================
                # 💥 核心改進：根據 dir(event) 提供的屬性精準提取
                # ==========================================
                original_text = ""
                
                # 1. 直接讀取 response_text (清單中明確存在)
                if hasattr(event, "response_text") and isinstance(event.response_text, str):
                    original_text = event.response_text
                
                # 2. 如果為空，嘗試掃描 reply_message_chain
                if not original_text.strip():
                    msg_chain = getattr(event, "reply_message_chain", [])
                    for msg in msg_chain:
                        if hasattr(msg, "text"):
                            original_text += msg.text
                        elif isinstance(msg, dict) and "text" in msg:
                            original_text += msg["text"]

                if not original_text.strip():
                    print(f"[{time.strftime('%H:%M:%S')}] ⏩ [安檢員] 提取文字失敗，放棄干預。")
                    return

                print(f"[{time.strftime('%H:%M:%S')}] 📄 [安檢員] 成功讀取文字 ({len(original_text)} 字)")

                # 讀取配置
                config = self.plugin.get_config() or {}
                rewrite_notice = config.get("rewrite_notice", "⚠️ [系統] 偵測到人格偏移，已執行 PUA 修正機制...")
                delay_time = float(config.get("delay_time", 0.8))

                is_modified = False
                reasons = []

                # --- 功能 3: 格式攔截 (XML/JSON 代碼) ---
                if "<function_call>" in original_text or '{"name":' in original_text:
                    is_modified = True
                    reasons.append("格式外洩")
                    original_text = re.sub(r"<function_call>.*?</function_call>", "", original_text, flags=re.DOTALL)
                    original_text = re.sub(r'\{"name":.*?\}', "", original_text, flags=re.DOTALL)
                    print(f"[{time.strftime('%H:%M:%S')}] 🚨 [安檢員] PUA生效：攔截並抹除代碼外洩！")

                # --- 功能 1 & 2: 言論重複懲罰 (人格修正) ---
                sentences = [s.strip() for s in re.split(r'[。！？\n]', original_text) if len(s.strip()) > 5]
                if sentences:
                    counts = Counter(sentences)
                    if any(count >= 2 for count in counts.values()):
                        is_modified = True
                        reasons.append("重複懲罰")
                        seen = set()
                        unique_sentences = []
                        for s in sentences:
                            if s not in seen:
                                unique_sentences.append(s)
                                seen.add(s)
                        original_text = "。".join(unique_sentences) + "。"
                        print(f"[{time.strftime('%H:%M:%S')}] 🚨 [安檢員] PUA生效：發現死循環，已重寫內容！")

                # --- 功能 5: 真人感分段發送 ---
                # 按換行符切分段落
                paragraphs = [p.strip() for p in re.split(r'\n+', original_text) if p.strip()]

                # 判定是否需要接管
                if not is_modified and len(paragraphs) <= 1:
                    print(f"[{time.strftime('%H:%M:%S')}] ✅ [安檢員] 安檢通過，放行發送。")
                    return

                # ==========================================
                # 💥 核心抓手：物理斷路原始發送
                # ==========================================
                ctx.prevent_default()
                self._HANDLED_ID_CACHE.add(unique_id)
                
                print(f"[{time.strftime('%H:%M:%S')}] 💥 [安檢員] 觸發攔截接管！分段數: {len(paragraphs)}")

                # --- 功能 4: 提醒 ---
                if is_modified:
                    await ctx.reply(platform_message.MessageChain([
                        platform_message.Plain(text=f"{rewrite_notice}\n(修正項: {'/'.join(reasons)})")
                    ]))
                    await asyncio.sleep(delay_time)

                # --- 分段發送流程 ---
                for i, para in enumerate(paragraphs):
                    print(f"[{time.strftime('%H:%M:%S')}] 📤 [安檢員] 分段發送 {i+1}/{len(paragraphs)}...")
                    await ctx.reply(platform_message.MessageChain([platform_message.Plain(text=para)]))
                    if i < len(paragraphs) - 1:
                        await asyncio.sleep(delay_time)

                print(f"[{time.strftime('%H:%M:%S')}] 🏁 [安檢員] 任務完成，人格設定已回正。")

            except Exception as e:
                print(f"[{time.strftime('%H:%M:%S')}] ❌ [安檢員] 異常: {e}")
            finally:
                async def clear_later():
                    await asyncio.sleep(30)
                    self._HANDLED_ID_CACHE.discard(unique_id)
                asyncio.create_task(clear_later())